library(stringr)
library(reshape2)

# read data
path <- "~/home/github/local/kis/data/data.csv"
raw <- read.csv(path, 
                skip = 1, 
                stringsAsFactors = FALSE, 
                check.names = FALSE, 
                header = FALSE)
#inhibitors <- read.csv(path, skip = 1, nrows = 1, header = FALSE, check.names = FALSE)

# clean data
data <- raw[3:302, 1:179]
inhibitor_names <- raw[1, 1:179]
inhibitor_names <- str_replace_all(unlist(inhibitor_names), "[ ]+", " ")
inhibitor_names <- str_replace_all(unlist(inhibitor_names), "\x9a", "o")
inhibitors <- raw[2, 1:179]
colnames(data) <- inhibitor_names
colnames(data)[1] <- "kinase"


# convert data to long format
data <- melt(data, 
             id.vars = "kinase", 
             variable.name = "compound", 
             value.name = "percent_activity")
data$compound <- as.character(data$compound)
data$percent_activity <- as.numeric(data$percent_activity)
data <- data[complete.cases(data), ]

save(data, file = "~/home/github/local/kis/data/data_clean.RData")